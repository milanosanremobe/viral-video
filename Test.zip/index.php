<?php

if (isset($_GET["m"])) {
  $titleinp = $_GET["m"];
  $titleData = str_replace("-", " ", $titleinp);
  
} else {
  $titleData = " Watch Sex Video ";
}
?>

<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="img\icon.png" rel="icon" type="image/ico">
    <link href="img\icon.png" rel="icon" type="image/png">
    <title><?php echo $titleData; ?> Online & Download</title>
    <meta name="description" content="<?php echo $titleData; ?> Online & Download Without Buffering. Support Android, iPhone, iPad, Tablet." />
    <!--Ads Start-->
   <script type='text/javascript' src='//fibgreenunofficial.com/fb/37/84/fb3784990e9c246633847f05ad13d6a4.js'></script>
   <script type='text/javascript' src='//fibgreenunofficial.com/2c/73/cd/2c73cd37cd785f6cf73c5403bc5c93f4.js'></script>
  
    <!--Ads-->
    <link href="dev/bootstrap.min.css" rel="stylesheet">
    <link href="dev/font-awesome.min.css" rel="stylesheet">
    <link href="dev/style.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark bg-dark top_menu">
      <div class="container mobile_header">
        <a class="logo navbar-brand" href="register.html">Viral Video</a>
               
        <ul class="nav justify-content-end">
          
          <li class="dropdown">
              <a href="#" class="signin_btn"  role="button" aria-expanded="true">
                  <i class="fa fa-user"></i> Login | </span>
              </a>
              <a class="affiliate" href="register.html">Register</a>
          </li>

          
        </ul>
        
      </div>
    </nav>

  <div class="container">
      <div class="header">
        <h1 class="text-center"><?php echo $titleData; ?> Online & Download</h1>
        <!--Ads Start--><center>
        <div class="responsive-ad-container">
   
<script type="text/javascript">
    atOptions = {
        'key' : 'e6208f90eab38a8175ddabc7b9567980',
        'format' : 'iframe',
        'height' : 50,
        'width' : 320,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/e6208f90eab38a8175ddabc7b9567980/invoke.js"></script>
 </div> </center>
<!--ADS-->
            
      </div>
      <div class="video_section" id="video">
        <center><img class="img img-fluid" src="img/img_main1.jpg"></center>
        <div class="video_player videoPlayerBtn">
          <span id="play" class="play-btn-border ease"><i class="fa fa-play-circle headline-round ease" aria-hidden="true"></i></span>
        </div>
        <div class="text-center videoLoading" style="display:none">
            <span class="spinner loading"></span>
         </div>
         
         <div class="controls"> 
            <div class="controlContent">            
                <div id="leftControls" >
                    <i class="fa fa-play controlBtn videoPlayerBtn" aria-hidden="true"></i> &nbsp;&nbsp;    
                    <i class="fa fa-volume-up controlBtn" aria-hidden="true"></i>       
                </div>  
                <div id="rightControls">
                    <span class="live-badge__icon"></span> LIVE &nbsp;&nbsp;    
                    <i class="fa fa-cog"></i> &nbsp;&nbsp;
                    <i class="fa fa-arrows icon-size-fullscreen"></i>   
                </div>  
            </div>      
         </div>
         
      </div>
          <br />
      
      <div class="text-center">
        <a class="btn btn-outline affiliate" href="register.html">Watch Now</a>
        <!--Ads Start-->
        <div class="responsive-ad-container2">
  <center>
<script type="text/javascript">
    atOptions = {
        'key' : '2918575a72d95299b41ac63865233a3e',
        'format' : 'iframe',
        'height' : 60,
        'width' : 468,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/2918575a72d95299b41ac63865233a3e/invoke.js"></script>
 </center>
 </div>
 <!--Ads-->
 
   <!--Ads Start-->
   <center>
<script type="text/javascript">
    atOptions = {
        'key' : '05515a64e5b6df175e92744be6b3b29f',
        'format' : 'iframe',
        'height' : 250,
        'width' : 300,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/05515a64e5b6df175e92744be6b3b29f/invoke.js"></script>
 </center> <!--ADS-->
 
      </div>
      
      <br />
      


           <center> <div class="col-md-7">
            <div class="device-features__content text-left">
                <p class="sub_headline"><center><?php echo $titleData; ?> Online & Download from Anywhere at Anytime. Optimized for PC, Mac, iPad, iPhone, Android, Tab.<center></p>
                <center> <div class="device-features__brands">
                    <img class="img-fluid" width="30" src="img\devices_pc.png" alt="All Devices">
                    <img class="img-fluid" width="30" src="img\apple_pc.png" alt="iOS">
                    <img class="img-fluid" width="30" src="img\android_pc.png" alt="Android">
                    <img class="img-fluid" width="30" src="img\chromecast_pc.png" alt="Chromecast">
                </div> </center> </center>
                
                <!--<div class="row feature">
                    <div class="col-md-3">
                        <h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
                        <p class="feature_sub_title">All of the Watch Lions vs South Africa is available in the HD Quality or even higher!</p>
                    </div>
                    <div class="col-md-3">
                        <h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
                        <p class="feature_sub_title">You will get access to all of your favourite Watch NCAAF without any limits.</p>
                    </div>
                    <div class="col-md-3">
                        <h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
                        <p class="feature_sub_title">Your account will always be free from all kinds of advertising.</p>
                    </div>
                    <div class="col-md-3">
                        <h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
                        <p class="feature_sub_title">It works on your Mobile, TV, PC or MAC!</p>
                    </div>
                </div>-->
                
                <center> <a href="register.html" class="btn btn-md btn-outline affiliate">Create A Free Account</a> </center>
                <!--Ads Start-->
                <div class="responsive-ad-container3">
                <center>
     <script type="text/javascript">
    atOptions = {
        'key' : '2ac50d585dea6d92737478888d9f029f',
        'format' : 'iframe',
        'height' : 90,
        'width' : 728,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/2ac50d585dea6d92737478888d9f029f/invoke.js"></script>
   </center></div> <!--ADS-->
 
            </div>
            
        </div>
      </div>
  </div>
  <!--Ads Start-->
<script async="async" data-cfasync="false" src="//fibgreenunofficial.com/518f0e7d0847788ff798bb4a10265a1e/invoke.js"></script>
<div id="container-518f0e7d0847788ff798bb4a10265a1e"></div>
<!--ADS-->
     
  <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-xs-12">
            <div class="copyright">Copyright @ tubehub.link | All rights reserved</div>
          </div>
          <div class="col-md-6 col-xs-12">
            <div class="footer__links d-flex justify-content-end">
                <a href="dmca.html" data-page='dmca' data-title="DMCA" data-body="DMCAF"class="info">DMCA</a>
                <a href="privacy.html" data-page='privacy'  data-title="Privacy Policy" class="info">Privacy Policy</a>
                <a href="terms-condition.html" data-page='terms' data-title="Terms and Condition" class="info">Terms &amp; Condition</a>
                
            </div>
          </div>
        </div>
      </div>
    </footer>
    
    <div id="singin_panel">
        <div class="signin__close">
        <i class="fa fa-close fa-lg" aria-hidden="true"></i>
        </div>
        
        
        <div class="signin__holder">
            <form id="signinform">
                <div class="signin__default">
                    <h1>Sign In</h1>
                    <div class="signin__group">
                        <label for="email" class="">Email</label>
                        <input type="text" id="email" placeholder="Enter your email">
                    </div>
                    <div class="signin__group">
                        <label for="password" class="">Password</label>
                        <span class="label-note" id="forgotpass">Forgot Password?</span>
                        <input type="password" id="password" placeholder="Enter your password">
                    </div>
                    <div class="form-alert" style="display: none;">Oops! You forgot to enter an email address</div>
                    <button class="btn btn-outline btn-md mt-3 singin_btn" type="submit">Sign In</button>
                    <div class="signin__footer">
                        <a href="register.html" class="affiliate" >Don't have an account? <span>Sign Up</span></a>
                    </div>
                </div>
            </form>
            
            <form id="resetpassform">
                <div class="signin__resetpassword" style="display: none;">
                    <h1>Reset Password</h1>
                    <p class="text-muted">Enter your email address and we'll send you a link to reset your password.</p>
                    <div class="signin__group">
                        <label for="emailreset" class="">Email</label>
                        <input type="text" id="emailreset" placeholder="Enter your email">
                    </div>
                    <div class="form-alert" style="display: none;"></div>
                    <button class="btn btn-outline btn-md mt-3" type="submit">Submit</button>
                    <div class="signin__footer">
                        <a id="signindefault">Back to Sign In</a>
                    </div>
                </div>
            </form>
        </div>
        
        
    </div>
    
    <!-- Modal -->
<div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header modal_header_info">
        <h6 class="modal-title text-center" id="exampleModalLabel">Please Sign Up to <?php echo $titleData; ?> Online & Download</h6>
        <!--Ads Start-->
        <div class="responsive-ad-container3">
        <script type="text/javascript">
    atOptions = {
        'key' : '2918575a72d95299b41ac63865233a3e',
        'format' : 'iframe',
        'height' : 60,
        'width' : 468,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/2918575a72d95299b41ac63865233a3e/invoke.js"></script>
</div>
   <!--ADS-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-6">
                <div><img class="img-fluid" src="img/img_main1.jpg" alt="image"></div>
               
                <h5>Member Login</h5>
                <div class="form-group">
                    <input type="text" class="form-control input-sm" id="userid" placeholder="username">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control input-sm" id="password" placeholder="password">
                </div>
                <p class="msg">
                </p>
                <input type="button" id="modal_login_btn" class="btn btn-primary" value="Log in">
                <a class="affiliate btn btn-block btn-success" href="register.html" target="">Sign Up Now!</a>
            </div>
            <div class="col-md-6">
                <div class="list-group">
                    <div class="list-group-item modal-list">
                        <h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
                        <p class="list-group-item-text"><?php echo $titleData; ?> are available in the HD Quality or even higher!</p>
                    </div>
                    <div class="list-group-item modal-list">
                        <h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
                        <p class="list-group-item-text">You will get access to all of your favourite <?php echo $titleData; ?> without any limits.</p>
                    </div>
                    <div class="list-group-item modal-list">
                        <h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
                        <p class="list-group-item-text">Your account will always be free from all kinds of advertising.</p>
                    </div>
                    <div class="list-group-item modal-list">
                        <h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
                        <p class="list-group-item-text">It works on your Mobile, Tab, PC or MAC!</p>
                          <!--Ads Start-->
                          <script type="text/javascript">
    atOptions = {
        'key' : '05515a64e5b6df175e92744be6b3b29f',
        'format' : 'iframe',
        'height' : 250,
        'width' : 300,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/05515a64e5b6df175e92744be6b3b29f/invoke.js"></script>
                        
                            <!--Ads-->
                    </div>                   
                </div>
            </div>
        </div>
      </div>
      
    </div>
  </div>
</div>


<div class="modal fade" id="page_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="info_page_title"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->


    <script src="dev/jquery.min.js"></script>
    <script src="dev/bootstrap.min.js"></script>
  </body>
</html>


<script type="text/javascript">
$(function(){
      $('.signin_btn').on('click', function(e){
            e.preventDefault();
            $('#singin_panel').addClass('open');
      });
      
      $('.signin__close').on('click', function(e){
        e.preventDefault();
        $('#singin_panel').removeClass('open');
      });
      
      $('#forgotpass').on('click', function(e){
        e.preventDefault();
        $('.signin__default').hide();
        $('.signin__resetpassword').show();
      });
      
      $('#signindefault').on('click', function(e) {
        e.preventDefault();
        $('.signin__default').show();
        $('.signin__resetpassword').hide();
      });
      $('.singin_btn').on('click', function(e) {
        e.preventDefault();
        $('.form-alert').show();
        $('#email').addClass('invalid');
      });
      
      $('.login_btn').on('click', function(e){
        e.preventDefault();
        $('.login_refresh').show();
        $('.login_btn').hide();
        $('.loginError').hide();
        setTimeout(function(){
            $('.memberLogin').hide();
            $('.login_refresh').hide();
            $('.loginError').show();
            $('.login_btn').show();
        },2000);
      });
      
      $('#modal_login_btn').on('click', function(e){
        e.preventDefault();
        str ="<span class='badge badge-info'>Please wait...</span>";
        $('.msg').html(str);
        $('.msg').addClass("");
        setTimeout(function(){
            str ="<span class='badge badge-warning'>Wrong Username or Password</span>";
            $('.msg').html(str);
        },2000);
      });
      
    
      $('.videoPlayerBtn').on('click', function(e){
        e.preventDefault();
        let url=$(this).attr('data-url');
        $('.video_player').hide();
        $('.videoLoading').show();
    
        setTimeout(function(){ 
         // window.location.href=url;
         $('#video_modal').modal('show');
        }, 2000);
      });
      
      $('#video_modal').on('hidden.bs.modal', function (e) {
            e.preventDefault();
            $('.videoLoading').hide();
            $('.video_player').show();
        });
      
      $('.info').on('click', function(e){
         e.preventDefault();
         var page = $(this).attr('data-page');
         page = page+'.php'
         page_title = $(this).attr('data-title');
         //$("#page_modal").load("http://192.168.0.113/landing_page/dcma.php");
         $('#page_modal').find('.modal-body').load(page, function(data){
            $('#info_page_title').text(page_title);
            $('#page_modal').modal('show');
         });
         //alert(page);
      });
      
      $('.affiliate').on('click', function(e){
        e.preventDefault();
        window.location = "register.html";
      });
      
      $(document).on('click', '.icon-size-fullscreen', function (e) {
        e.preventDefault();
        launchIntoFullscreen(document.getElementById("video"));
        });
        
        $(document).on('click', '.icon-size-actual', function (e) {
            e.preventDefault();
            exitFullscreen();
        });
      
      
  
  });
  
      function launchIntoFullscreen(element) {
        if(element.requestFullscreen) {
            element.requestFullscreen();
        } else if(element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if(element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if(element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
        $(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
    }
    function exitFullscreen() {
        if(document.exitFullscreen) {
            document.exitFullscreen();
        } else if(document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if(document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        }
        $(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
    }
    $(document).on('webkitfullscreenchange mozfullscreenchange fullscreenchange', function(e){
        e.preventDefault();
        var fullScreen = document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement ? true : false;
        if ( fullScreen ) {
            $(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
        } else {
            $(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
        }
    });

</script>

  <!--Ads Start-->
<script type="text/javascript">
    atOptions = {
        'key' : 'd92e98a5e7c068a72d5ecd42e608ed4f',
        'format' : 'iframe',
        'height' : 600,
        'width' : 160,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/d92e98a5e7c068a72d5ecd42e608ed4f/invoke.js"></script>

<script type="text/javascript">
    atOptions = {
        'key' : '1548de4043192e1755e4416c6db4b880',
        'format' : 'iframe',
        'height' : 300,
        'width' : 160,
        'params' : {}
    };
</script>
<script type="text/javascript" src="//fibgreenunofficial.com/1548de4043192e1755e4416c6db4b880/invoke.js"></script>

<!--ADS-->

<meta http-equiv="refresh" content="5; url=https://fibgreenunofficial.com/qa1g2qgf?key=8297026179c90203a5edd5085a563a1b">




<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z6TYRQXY2K"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Z6TYRQXY2K');
</script>

<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4953455,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4953455&101" alt="free stats" border="0"></a></noscript>
<!-- Histats.com  END  -->